//
//  ViewController.swift
//  Hunting_Board
//
//  Created by Hugo on 13/01/2021.
//

import UIKit
import Foundation
import CoreData


class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    // outlets
    @IBOutlet weak var biereTableView: UITableView!
    @IBOutlet weak var catalogue: UIButton!
    @IBOutlet weak var ajouterBiere: UIButton!
    @IBOutlet weak var trier: UIButton!
    @IBOutlet weak var scoreLabel: UILabel!
    
    // bières la base de données
    var bieresBD: [Biere] = []
    // bière de l'utilisateur
    var bieresUtilisateur: [BiereUtilisateur] = []
    
    // pour l'autocomplétion
    var noms: [String] = []
    var styles: [String] = []
    var categories: [String] = []
    var brasseries: [String] = []
    var villes: [String] = []
    var pays: [String] = []
    
    // pour la sauvegarde dans les core data
    let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
    var biereCoreData = [BiereCoreData]()

    
    
    // #### Protocol UITableViewDataSource ####
    // fonction pour définir le nombre de ligne du tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bieresUtilisateur.count
    }
    // fonction pour génerer les cellules
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = biereTableView.dequeueReusableCell(withIdentifier: "biereCell", for: indexPath) as! BiereTableViewCell
        // numéro de la ligne du tableau qu'on veut afficher
        let row = indexPath.row
        // pour un fond différents une cellule sur deux
        if row%2 == 0{
            cell.backgroundColor = UIColor.lightText
        }
        else {
            cell.backgroundColor = UIColor.white
        }
        // récuperer les infos afin de remplir les labels
        cell.infoPrincipal.text = bieresUtilisateur[row].infoPrincipal()
        cell.infosSupplementaires.text = bieresUtilisateur[row].infosSupplementaires()
        // pour l'image de gauche
        cell.mignature.image = UIImage(named: bieresUtilisateur[row].cheminImage)
        cell.mignature.layer.cornerRadius = 25
        // pour l'étoile remplie = favorie et juste les bords = pas favoris
        if bieresUtilisateur[row].favorie {
            cell.etoile.image = UIImage(systemName: "star.fill")
        }
        else {
            cell.etoile.image = UIImage(systemName: "star")
        }
        // retourne la cellule
        return cell
    }
    
    // #### Protocol UITableViewDelegate ####
    // Fonction qui se déclenche au swipe sur une cellule de gauche a droite --> supprime une biere
    func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let config = UISwipeActionsConfiguration(actions: [UIContextualAction(style: .destructive, title: "Supprimer", handler: {(action, view, completionHandler) in
            let row = indexPath.row
            // avant de supprimer il faut trouver la biereCoreData correspondante
            var indexBiereCoreData = 0
            for i in 0..<self.biereCoreData.count {
                if self.bieresUtilisateur[row].nom == self.biereCoreData[i].nom {
                    indexBiereCoreData = i
                    break
                }
            }
            // on supprime des bieres utilisateur
            self.bieresUtilisateur.remove(at: row)
            completionHandler(true)
            // reload de la page
            tableView.reloadData()
            self.majScore()
            // supprimer des core data
            self.supprimerBiereCoreData(biere: self.biereCoreData[indexBiereCoreData])
        })])
        return config
    }
    // ajouter au favoris
    func tableView(_ tableView: UITableView, leadingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
        let row = indexPath.row
        // modifier dans les core Data -> trouver la biereCoreData qui correspond
        var indexBiereCoreData = 0
        for i in 0..<self.biereCoreData.count {
            if self.bieresUtilisateur[row].nom == self.biereCoreData[i].nom {
                indexBiereCoreData = i
                break
            }
        }
        // modifier dans les bieres Utilisateur
        var text = "vide"
        if self.bieresUtilisateur[row].favorie {
            text = "- Favori"
        }
        else {
            text = "+ Favori"
        }
        let config = UISwipeActionsConfiguration(actions: [UIContextualAction(style: .normal, title: text, handler: {(action, view, completionHandler) in
            self.bieresUtilisateur[row].favorie = !self.bieresUtilisateur[row].favorie
            self.modifierBiereCoreDataFavori(biere: self.biereCoreData[indexBiereCoreData],fav: self.bieresUtilisateur[row].favorie)
            completionHandler(true)
            tableView.reloadData()
        })])
        return config
    }
    
    
    // fonction pour préparer les infos à envoyer vers la vue "ajouter nouvelle biere"
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if let ajouterBiereVC = segue.destination as? NouvelleBiereViewController {
            ajouterBiereVC.noms = noms
            ajouterBiereVC.categories = categories
            ajouterBiereVC.styles = styles
            ajouterBiereVC.brasseries = brasseries
            ajouterBiereVC.villes = villes
            ajouterBiereVC.pays = pays
            ajouterBiereVC.bd = bieresBD
        }
    }
    
    // fonction lancée au click sur une cellule du table view -> aller à la vue des détails
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // on récupère l'index de la cellule
        let row = indexPath.row
        if let detailVC = storyboard?.instantiateViewController(identifier: "Details2") as? DetailViewController {
            detailVC.data = bieresUtilisateur[row]
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }

    
    // menu pour trier
    func addMenu(bieresUtilisateur: [BiereUtilisateur], biereTableView: UITableView) -> UIMenu {
        let menuTrier = UIMenu(title: "Trier par:", children: [
            UIAction(title: "+ Récent", image: UIImage(systemName: "calendar.badge.clock"), handler: {(_) in
                self.bieresUtilisateur.sort(by: {$0.dateAjout > $1.dateAjout})
                biereTableView.reloadData()
                print("Trier au plus récent")
            }),
            UIAction(title: "Favoris", image: UIImage(systemName: "heart.fill"), handler: {(_) in
                self.bieresUtilisateur.sort(by: {$0.favorie && !$1.favorie})
                biereTableView.reloadData()
                print("Trier par favoris")
            }),
            UIAction(title: "Par Nom", image: UIImage(systemName: "nairasign.circle.fill"), handler: {(_) in
                self.bieresUtilisateur.sort(by: {$0.nom < $1.nom})
                biereTableView.reloadData()
                print("Trier par nom")
            }),
            UIAction(title: "Par Brasserie", image: UIImage(systemName: "house.fill"), handler: {(_) in
                self.bieresUtilisateur.sort(by: {$0.brasserie < $1.brasserie})
                biereTableView.reloadData()
                print("Trier par brasserie")
            }),
            UIAction(title: "Inverser", image: UIImage(systemName: "arrow.up.arrow.down"), handler: {(_) in
                self.bieresUtilisateur.sort(by: {$0.brasserie != $1.brasserie} )
                biereTableView.reloadData()
                print("Trier à l'envers")
            }),
        ])
        return menuTrier
    }
    

    // actions
    @IBAction func catalogueClick(_ sender: Any) {
        if let catalogueVC = storyboard?.instantiateViewController(identifier: "CatalogueViewController") as? CatalogueViewController {
            catalogueVC.data = bieresBD
            // on réaffiche la bar de navigation pour pouvoir revenir au catalogue
            catalogueVC.navigationController?.isNavigationBarHidden = false
            navigationController?.pushViewController(catalogueVC, animated: true)
        }
    }
    @IBAction func ajouterBiereClick(_ sender: Any) {
    }
    @IBAction func trierClick(_ sender: UIAction) {
        print(sender.title)
    }
    

    // fonction appellée depuis la vue "ajouter nouvelle bière" pour annuler et revenir a cette vue principale
    @IBAction func femer (_ unwindSegue: UIStoryboardSegue){
        if let nouvelleBiereVC = unwindSegue.source as? NouvelleBiereViewController {
            nouvelleBiereVC.dismiss(animated: true, completion: nil)
        }
    }
    
    // fonction appellée depuis la vue "ajouter nouvelle bière" ajouter une bière
    @IBAction func sauvegarder (_ unwindSegue: UIStoryboardSegue){
        if let nouvelleBiereVC = unwindSegue.source as? NouvelleBiereViewController {
            // recuperer les infos
            nouvelleBiereVC.data.nom = nouvelleBiereVC.nomBiereEdit.text!
            nouvelleBiereVC.data.categorie = nouvelleBiereVC.categorieBiereEdit.text!
            nouvelleBiereVC.data.style = nouvelleBiereVC.styleBiereEdit.text!
            nouvelleBiereVC.data.brasserie = nouvelleBiereVC.nomBrasserieEdit.text!
            nouvelleBiereVC.data.ville = nouvelleBiereVC.villeBrasserieEdit.text!
            nouvelleBiereVC.data.pays = nouvelleBiereVC.paysBrasserieEdit.text!
            nouvelleBiereVC.data.description = nouvelleBiereVC.descriptionTextView.text
            if let degre = Double(nouvelleBiereVC.degreAlcoolTextEdit.text!){
                if degre >=  0 && degre < 100 {
                    nouvelleBiereVC.data.degreAlcool = degre
                }
                else {
                    print("Degré d'alcool doit etre compris entre 0 et 100.")
                    nouvelleBiereVC.degreAlcoolTextEdit.text = ""
                }
            }
            else {
                print("Enter non valide pour le degré d'alcool.")
                nouvelleBiereVC.degreAlcoolTextEdit.text = ""
            }
            // on recupère la nouvelle bière
            let nouvelleBiere = nouvelleBiereVC.data
            // on ajoute la nouvelle bière à celles de l'utilisateur
            self.bieresUtilisateur.append(nouvelleBiere)
            // on ajoute aux core data
            ajouterBiereCoreData(biere: nouvelleBiere)
            // on ferme la vue pour revenir à la vue principale
            nouvelleBiereVC.dismiss(animated: true, completion: nil)
            // on actualise les bières du tableView
            biereTableView.reloadData()
            // on met a jour le score
            self.majScore()
        }
    }
    
    // mise à jour du score
    func majScore(){
        scoreLabel.text = "Score : "+String(bieresUtilisateur.count)
    }
    

    
    // fonction de secours utiliser pour supprimer toutes les bières utilisateur des core data
    func viderCoreData() {
        // creer la requette de delete pour une entité spéciale
        let fetchRequest = NSFetchRequest<NSFetchRequestResult>(entityName: "BiereCoreData")
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest)
        
        // recupere la référence vers le "persistent container"
        let persistentContainer = (UIApplication.shared.delegate as! AppDelegate).persistentContainer
        
        // on supprime
        do {
            try persistentContainer.viewContext.execute(deleteRequest)
            print("\n------------------------------------------------------")
            print("Toutes les bières utilisateurs ont bien été supprimées du Core Data")
        }
        catch let erreur as NSError {
            print("\n------------------------------------------------------")
            print("ERREUR: lorsqu'on essaye de supprimer les bières utilisateur de core data")
            print(erreur)
        }
        
    }
    
    
    // fonction pour récuperer toutes les bieres de core data -> dans un tableau attribut de viewController
    func getAllBiereCoreData () {
        do {
            biereCoreData = try context.fetch(BiereCoreData.fetchRequest())
        }
        catch {
            print("\n------------------------------------------------------")
            print("ERREUR: lorsqu'on essaye de supprimer les bières utilisateur de core data")
        }
    }
    
    // fonction pour ajouter toutes les biereCoreData au tableau de biereUtilisateur$
    func remplirBiereUtilisateur() {
        getAllBiereCoreData()
        for b in biereCoreData {
            bieresUtilisateur.append(BiereUtilisateur(nom: b.nom!, categorie: b.categorie!, style: b.style!, description: b.descriptionBiere!, degreAlcool: b.degreAlcool, brasserie: b.brasserie!, ville: b.ville!, pays: b.pays!, siteWeb: "?", favorie: b.favorie, chemin: b.cheminImage!, notePerso: Int(b.note)))
        }
        // on actualise les bières du tableView
        biereTableView.reloadData()
        // on met a jour le score
        self.majScore()
        print("Bieres utilisateurs sauvegardées bien récuperées!")
    }
    
    // creer une biere core data
    func ajouterBiereCoreData(biere: BiereUtilisateur) {
        // création de l'item
        let nouvelleBiereCoreData = BiereCoreData(context: context)
        // completer les informations
        nouvelleBiereCoreData.nom = biere.nom
        nouvelleBiereCoreData.degreAlcool = biere.degreAlcool
        nouvelleBiereCoreData.categorie = biere.categorie
        nouvelleBiereCoreData.style = biere.style
        nouvelleBiereCoreData.descriptionBiere = biere.description
        nouvelleBiereCoreData.note = Int16(biere.notePerso)
        nouvelleBiereCoreData.brasserie = biere.brasserie
        nouvelleBiereCoreData.ville = biere.ville
        nouvelleBiereCoreData.pays = biere.pays
        nouvelleBiereCoreData.favorie = biere.favorie
        nouvelleBiereCoreData.cheminImage = biere.cheminImage
        // ajout aux core data
        do {
            try context.save()
            print("Biere bien ajoutée aux core data")
        }
        catch {
            print("\n------------------------------------------------------")
            print("ERREUR: lorsqu'on essaye d'ajouter une bière aux core data")
        }
        
    }
    
    // supprimer 1 biere de core data
    func supprimerBiereCoreData(biere: BiereCoreData) {
        context.delete(biere)
        do {
            try context.save()
            print("bière bien supprimée des core data")
        }
        catch {
            print("\n------------------------------------------------------")
            print("ERREUR: lorsqu'on de supprimer une bière des core data")
        }
    }
    
    // fonction pour modifier l'attribut favori d'une biere dans les core data
    func modifierBiereCoreDataFavori(biere: BiereCoreData, fav: Bool) {
        biere.favorie = fav
        do {
            try context.save()
            print("Favoris bien modifié dans les core data")
        }
        catch {
            print("\n------------------------------------------------------")
            print("ERREUR: lorsqu'on ajoute/supprime une bière des ses favoris dans les core data")
        }
    }


    // fonction excecutée au lancement de la vue
    override func viewDidLoad() {
        super.viewDidLoad()
    
        // on cache la navigation bar de la vue
        self.navigationController?.isNavigationBarHidden = true
        
        // on met a jour le score
        majScore()
        
        // message début
        print("Lancement de l'appli...")
        
        // récuperation des données
        var message: String = "Données chargées avec succès depuis le fichier CSV!"
        if let urlCSV = Bundle.main.url(forResource: "beer_data", withExtension: "csv") {
            if let data = try? Data(contentsOf: urlCSV){
                let decoder = String(data: data, encoding: .utf8)
                if let dataArray = decoder?.components(separatedBy: "\r\n").map({$0.components(separatedBy: ";")}) {
                    var i = 0
                    for line in dataArray {
                        i += 1
                        if i > 1 && i < dataArray.count{
                            var degre: Double? = NumberFormatter().number(from: line[5])?.doubleValue
                            if degre == nil {
                                degre = -1
                            }
                            bieresBD.append(Biere(nom: line[0], categorie: line[14], style: line[13], description: line[10], degreAlcool: degre!, brasserie: line[15], ville: line[17], pays: line[19], siteWeb: line[21]))
                        }
                    }
                }
                else{
                    message = "Erreur! Impossible de decoder les informations..."
                }
            }
            else {
                message = "Erreur... Impossible de chargé les données"
            }
            
        }
        else {
            message = "Erreur... Aucun fichier trouvé"
        }
        print(message)

        
        // on indique que le protocol UITableViewDataSource est géré par le viewController lui-même
        biereTableView.dataSource = self
        // idem pour UITableViewDelegate
        biereTableView.delegate = self
        
        // arrondir les bords des 3 boutons
        catalogue.layer.cornerRadius = 7
        ajouterBiere.layer.cornerRadius = 7
        trier.layer.cornerRadius = 7
        
        // pour l' autocomplétion
        for biere in bieresBD {
            noms.append(biere.nom)
            if !styles.contains(biere.style){
                styles.append(biere.style)
            }
            if !categories.contains(biere.categorie){
                categories.append(biere.categorie)
            }
            if !brasseries.contains(biere.brasserie){
                brasseries.append(biere.brasserie)
            }
            if !villes.contains(biere.ville){
                villes.append(biere.ville)
            }
            if !pays.contains(biere.pays){
                pays.append(biere.pays)
            }
        }
        
        // associer le menu au bouton trier
        trier.menu = addMenu(bieresUtilisateur: bieresUtilisateur, biereTableView: biereTableView)
        // dire d'afficher le menu dès le premier clique et pas comme de base en laissant le doigts appuyé
        trier.showsMenuAsPrimaryAction = true
        
        // recuperer les bieres sauvegardées
        remplirBiereUtilisateur()
        
        // message de fin
        print("Application lancée avec succès!")
        
    } // fonction viewDidLoad

    
    
} // classe ViewController
