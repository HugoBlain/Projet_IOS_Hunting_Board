//
//  DetailViewController.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 14/01/2021.
//

import UIKit

class DetailViewController: UIViewController {

    // fonction lancée au lancement de la vue Detail
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // on afficher la navigation bar de la vue
        self.navigationController?.isNavigationBarHidden = false
        
        // si on a bien récuperé des données
        if let biere = data{
            nomBiereTE.text = biere.nom
            degreTE.text = String(biere.degreAlcool)
            categorieTE.text = biere.categorie
            styleTE.text = biere.style
            descriptionTV.text = biere.description
            brasserieTE.text = biere.brasserie
            villeTE.text = biere.ville
            paysTE.text = biere.pays
            if biere.notePerso != -1 {
                scoreB.setTitle(String(biere.notePerso), for: .normal)
                // affiche la date dans la barre du haut
                let formatter = DateFormatter()
                formatter.dateStyle = .short
                formatter.locale = Locale(identifier: "FR-fr")
                self.navigationItem.title = "Ajoutée le :"+formatter.string(from: biere.dateAjout)
            }
            // note = -1 -> détail appelé depuis le catalogue
            else {
                scoreB.isHidden = true
                imageIV.isHidden = true
            }
        }
        else {
        }
    }
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
    // fonction lancée quand on quitte la vue des détails --> cache de nouveau la navigation bar
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    // outlets

    @IBOutlet weak var nomBiereTE: UITextField!
    @IBOutlet weak var degreTE: UITextField!
    @IBOutlet weak var categorieTE: UITextField!
    @IBOutlet weak var styleTE: UITextField!
    @IBOutlet weak var descriptionTV: UITextView!
    @IBOutlet weak var brasserieTE: UITextField!
    @IBOutlet weak var villeTE: UITextField!
    @IBOutlet weak var paysTE: UITextField!
    @IBOutlet weak var imageIV: UIImageView!
    @IBOutlet weak var scoreB: UIButton!
    @IBOutlet weak var retourBouton: UIButton!
    
    
    // bière dont on affiche les détails
    var data: BiereUtilisateur?
    
    
}
