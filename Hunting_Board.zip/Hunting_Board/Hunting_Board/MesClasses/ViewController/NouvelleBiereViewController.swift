//
//  NouvelleBiereViewController.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 14/01/2021.
//

import UIKit

// classe pour la vue qui permet d'ajouter une bière utilisateur
class NouvelleBiereViewController: UIViewController, UITextFieldDelegate, UIImagePickerControllerDelegate, UINavigationControllerDelegate {

    
    // #### Protocol UITextFieldDelegate ####
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        // fonction pour ranger le clavier après une saisie
        // pour comfirmer l'autocomplétion
        nomBiereEdit.resignFirstResponder()
        categorieBiereEdit.resignFirstResponder()
        styleBiereEdit.resignFirstResponder()
        nomBrasserieEdit.resignFirstResponder()
        villeBrasserieEdit.resignFirstResponder()
        paysBrasserieEdit.resignFirstResponder()
        return true
    }
    // fonction pour l'autocomplétion des textFields
    // différents tableaux contenant les suggestions en fonction du textEdit en question
    func textField(_ textField: UITextField, shouldChangeCharactersIn range: NSRange, replacementString string: String) -> Bool {
        if textField == nomBiereEdit {
            if let suggestion = noms {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucune bière dispo")
            }
        }
        else if textField == categorieBiereEdit{
            if let suggestion = categories {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucune catégorie dispo")
            }
        }
        else if textField == styleBiereEdit{
            if let suggestion = styles {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucun style dispo")
            }
        }
        else if textField == nomBrasserieEdit{
            if let suggestion = brasseries {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucune brasserie dispo")
            }
        }
        else if textField == villeBrasserieEdit{
            if let suggestion = villes {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucune ville dispo")
            }
        }
        else if textField == paysBrasserieEdit{
            if let suggestion = pays {
                return !autoCompleteText(in: textField, using: string, suggestionsArray: suggestion)
            }
            else {
                print("Aucun pays dispo")
            }
        }
        return !autoCompleteText(in: textField, using: string, suggestionsArray: ["erreur"])
    }
    
    // fonction de recherche pour l'autocomplétion
    func autoCompleteText( in textField: UITextField, using string: String, suggestionsArray: [String]) -> Bool {
            if !string.isEmpty,
                let selectedTextRange = textField.selectedTextRange,
                selectedTextRange.end == textField.endOfDocument,
                let prefixRange = textField.textRange(from: textField.beginningOfDocument, to: selectedTextRange.start),
                let text = textField.text( in : prefixRange) {
                let prefix = text + string
                let matches = suggestionsArray.filter {
                    $0.hasPrefix(prefix)
                }
                if (matches.count > 0) {
                    textField.text = matches[0]
                    if let start = textField.position(from: textField.beginningOfDocument, offset: prefix.count) {
                        textField.selectedTextRange = textField.textRange(from: start, to: textField.endOfDocument)
                        return true
                    }
                }
            }
            return false
        }
    
    
    // action lancée quand le nom de la biere à été entré
    // si le nom est dans la base de données alors on complète auto les autres champs
    @IBAction func completerLesChamps(_ sender: Any) {
        print("Nom de la bière saisi")
        // si la base de données à bien été passée
        if let baseDeDonnees = bd {
            // si le nom est bien remplie
            if let nomDeLaBiere = nomBiereEdit.text {
                // non vide
                if !nomDeLaBiere.isEmpty {
                    // si ok on cherche l'index de la bière dans la base de données
                    var index = -1
                    for j in 0..<baseDeDonnees.count {
                        if baseDeDonnees[j].nom == nomDeLaBiere {
                            index = j
                        }
                    }
                    // si l'index a été trouvée
                    if index != -1 {
                        categorieBiereEdit.text = baseDeDonnees[index].categorie
                        styleBiereEdit.text = baseDeDonnees[index].style
                        nomBrasserieEdit.text = baseDeDonnees[index].brasserie
                        villeBrasserieEdit.text = baseDeDonnees[index].ville
                        paysBrasserieEdit.text = baseDeDonnees[index].pays
                        degreAlcoolTextEdit.text = String(baseDeDonnees[index].degreAlcool)
                        print("Les autres champs ont bien été remplis")
                    }
                }
                else {
                    print("Nom de bière vide")
                }
            }
        }
        else {
            print("Base de données pas trouvée")
        }
    }
    
    @IBAction func entrerDegreAlcool(_ sender: Any) {
        if let degre = Double(degreAlcoolTextEdit.text!){
            if degre >=  0 && degre < 100 {
                data.degreAlcool = degre
            }
            else {
                print("Degré d'alcool doit etre compris entre 0 et 100.")
                degreAlcoolTextEdit.text = ""
            }
        }
        else {
            print("Enter non valide pour le degré d'alcool.")
            degreAlcoolTextEdit.text = ""
        }
    }
    
    
    
    // action --> quand on appuie sur savegarder on charge les données avants de les envoyer
    @IBAction func sauvegarder(_ sender: Any) {
    }

    // fonction quand on clique sur une étoile poyr donner une note
    // /!\ les tags des étoiles vont de 1 à 5 alors que les boutons dans la collections de outlets vont de 0 à 4
    @IBAction func clickEtoiles(_ sender: UIButton) {
        // exemple 3/5 -> les 3 premières images deviennent pleines et les deux dernières vide
        // remarque -> on doit à chaque fois repréciser le symbolScale = large pour que nosétoile reste large
        for i in 0..<sender.tag {
            etoileCollectionBouton[i].setImage(UIImage(systemName: "star.fill", withConfiguration: UIImage.SymbolConfiguration(scale: .large)), for: .normal)
        }
        for i in sender.tag..<5 {
            etoileCollectionBouton[i].setImage(UIImage(systemName: "star", withConfiguration: UIImage.SymbolConfiguration(scale: .large)), for: .normal)
        }
        // on met a jour la note de la biere
        data.notePerso = sender.tag
    }
    
    
    // méthode pour ajouter une photo
    
    @IBAction func ajouterPhoto(_ sender: UIButton) {
        // vue qui va souvrir
        let picker = UIImagePickerController()
        picker.delegate = self
        picker.sourceType = .photoLibrary
        
        // on ajoute le picker a la vue actuelle
        present(picker, animated: true, completion: nil)
    }
    
    func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
        //print(info[UIImagePickerController.InfoKey.originalImage].)
        dismiss(animated: true, completion: nil)
    }
    
    
    
    // fonction lancée au lancement de la vue
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // arrondir les angles du bouton sauvegarder
        sauvegarderBouton.layer.cornerRadius = 10
        
        // pour chacun des textField on précise pour le protocol Delegate
        nomBiereEdit.delegate = self
        categorieBiereEdit.delegate = self
        styleBiereEdit.delegate = self
        nomBrasserieEdit.delegate = self
        villeBrasserieEdit.delegate = self
        paysBrasserieEdit.delegate = self
        
        
    } // fonction viewDidLoad
    
    
    // outlets
    @IBOutlet weak var nomBiereEdit: UITextField!
    @IBOutlet weak var categorieBiereEdit: UITextField!
    @IBOutlet weak var styleBiereEdit: UITextField!
    @IBOutlet weak var descriptionTextView: UITextView!
    @IBOutlet weak var nomBrasserieEdit: UITextField!
    @IBOutlet weak var villeBrasserieEdit: UITextField!
    @IBOutlet weak var paysBrasserieEdit: UITextField!
    @IBOutlet weak var sauvegarderBouton: UIButton!
    @IBOutlet var etoileCollectionBouton: [UIButton]!
    @IBOutlet weak var degreAlcoolTextEdit: UITextField!
    
    
    // bière qu'on veut souhaite ajouter
    var data = BiereUtilisateur()
    
    // pour l'autocomplétion
    var noms: [String]?
    var styles: [String]?
    var categories: [String]?
    var brasseries: [String]?
    var villes: [String]?
    var pays: [String]?
    var bd: [Biere]?
    
    
    // autocomplétion
    let suggestionsArray = ["black", "blue", "green", "yellow"]
    
    
} // classe NouvelleBiereViewController


