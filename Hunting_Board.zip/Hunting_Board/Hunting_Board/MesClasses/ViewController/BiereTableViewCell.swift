//
//  BiereTableViewCell.swift
//  Hunting_Board
//
//  Created by Hugo on 13/01/2021.
//

import UIKit
import Foundation


class BiereTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

    @IBOutlet weak var mignature: UIImageView!
    @IBOutlet weak var infoPrincipal: UILabel!
    @IBOutlet weak var infosSupplementaires: UILabel!
    @IBOutlet weak var etoile: UIImageView!
    
    
}
