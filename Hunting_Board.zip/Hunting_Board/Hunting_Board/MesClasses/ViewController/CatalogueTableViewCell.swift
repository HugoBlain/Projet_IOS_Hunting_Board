//
//  CatalogueTableViewCell.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 28/01/2021.
//

import UIKit


// classe des cellules de catalogue
class CatalogueTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }

    // outlets cellules
    @IBOutlet weak var infoPrincipale: UILabel!
    @IBOutlet weak var infoSupplementaire: UILabel!
    @IBOutlet weak var mignature: UIImageView!
    
}
