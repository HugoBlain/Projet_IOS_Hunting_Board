//
//  CatalogueViewController.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 27/01/2021.
//

import UIKit

class CatalogueViewController: UIViewController, UITableViewDataSource, UITableViewDelegate{
    
    // nombre de ligne du tableView
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return data!.count
    }
    
    
    // generer les cellules
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = catalogueTableView.dequeueReusableCell(withIdentifier: "catalogueCell", for: indexPath) as! CatalogueTableViewCell
        // numéro de la ligne du tableau qu'on veut afficher
        let row = indexPath.row
        // pour un fond différents une cellule sur deux
        if row%2 == 0{
            cell.backgroundColor = UIColor.lightText
        }
        else {
            cell.backgroundColor = UIColor.white
        }
        // récuperer les infos afin de remplir les labels
        cell.infoPrincipale.text = data![row].infoPrincipal()
        cell.infoSupplementaire.text = data![row].infosSupplementaires()
        // pour l'image de gauche
        cell.mignature.image = UIImage(named: "parDefaut")
        cell.mignature.layer.cornerRadius = 25
        // retourne la cellule
        return cell
    }
    
    // fonction lancée au click sur une cellule du table view -> aller à la vue des détails
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        // on récupère l'index de la cellule
        let row = indexPath.row
        if let detailVC = storyboard?.instantiateViewController(identifier: "Details2") as? DetailViewController {
            let temp = BiereUtilisateur(biere: data![row], favorie: false, chemin: "parDefaut", notePerso: -1)
            detailVC.data = temp
            navigationController?.pushViewController(detailVC, animated: true)
        }
    }
    

    // au lancement de la vue
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // on afficher la navigation bar de la vue
        self.navigationController?.isNavigationBarHidden = false
        
        catalogueTableView.dataSource = self
        catalogueTableView.delegate = self
    }
    
    // fonction lancée quand on quitte la vue des détails --> cache de nouveau la navigation bar
    override func viewWillDisappear(_ animated: Bool)
    {
        super.viewWillDisappear(animated)
        self.navigationController?.isNavigationBarHidden = true
    }
    
    // outlets
    @IBOutlet weak var catalogueTableView: UITableView!
    
    
    // bieres de la base de données
    var data: [Biere]?
    
    override func viewWillAppear(_ animated: Bool) {
        self.navigationController?.isNavigationBarHidden = false
    }
    
}
