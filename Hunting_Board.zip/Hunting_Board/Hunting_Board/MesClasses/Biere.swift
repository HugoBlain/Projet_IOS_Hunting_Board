//
//  Biere.swift
//  Hunting_Board
//
//  Created by Hugo on 13/01/2021.
//

import Foundation


// classe pour représenter nos bières
class Biere {
    // attributs
    var nom: String
    var categorie: String
    var style: String
    var degreAlcool: Double
    var description: String
    var brasserie: String
    var ville: String
    var pays: String
    var siteWeb: String
    
    // constructeur
    init(nom: String = "Inconnu", categorie: String = "Inconnue", style: String = "Inconnu", description: String = "Vide", degreAlcool: Double = -1, brasserie: String = "Inconnue", ville: String = "Inconnue", pays: String = "Inconnu", siteWeb: String = "Inconnu") {
        self.nom = nom
        self.categorie = categorie
        self.style = style
        self.degreAlcool = degreAlcool
        self.description = description
        self.brasserie = brasserie
        self.ville = ville
        self.pays = pays
        self.siteWeb = siteWeb
    }
    
    // pour le remplissage des cellules du table view
    func infoPrincipal() -> String {
        return self.nom+" ("+String(format: "%.1f", self.degreAlcool)+"%)"
    }
    func infosSupplementaires() -> String {
        return "Style: "+self.style
    }
    
    
    // affichage sympa dans le terminal
    func toString() -> String {
        var message: String
        message = "\n"+self.nom
        message += "\n\t Catégorie : "+self.categorie
        message += "\n\tStyle : "+self.style
        message += "\n\t Degré : "+String(format: "%.1f", self.degreAlcool)
        message += "\n\t Description : "+String(self.description)
        message += "\n\t Brasserie : "+String(self.brasserie)
        message += "\n\t\t Ville : "+String(self.ville)
        message += "\n\t\t Site Web :"+String(self.siteWeb)
        return message
    }
}
