//
//  BiereCoreData+CoreDataClass.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 28/01/2021.
//
//

import Foundation
import CoreData

@objc(BiereCoreData)
public class BiereCoreData: NSManagedObject {

}
