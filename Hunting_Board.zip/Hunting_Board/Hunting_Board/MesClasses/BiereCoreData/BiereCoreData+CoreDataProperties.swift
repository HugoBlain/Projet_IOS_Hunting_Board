//
//  BiereCoreData+CoreDataProperties.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 28/01/2021.
//
//

import Foundation
import CoreData


extension BiereCoreData {

    // fetch request
    @nonobjc public class func fetchRequest() -> NSFetchRequest<BiereCoreData> {
        return NSFetchRequest<BiereCoreData>(entityName: "BiereCoreData")
    }

    // propriétés
    @NSManaged public var brasserie: String?
    @NSManaged public var categorie: String?
    @NSManaged public var cheminImage: String?
    @NSManaged public var dateAjout: Date?
    @NSManaged public var degreAlcool: Double
    @NSManaged public var descriptionBiere: String?
    @NSManaged public var favorie: Bool
    @NSManaged public var nom: String?
    @NSManaged public var note: Int16
    @NSManaged public var pays: String?
    @NSManaged public var style: String?
    @NSManaged public var ville: String?

}

extension BiereCoreData : Identifiable {

}
