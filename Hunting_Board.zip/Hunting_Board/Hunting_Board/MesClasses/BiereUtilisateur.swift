//
//  BiereUtilisateur.swift
//  Hunting_Board
//
//  Created by Lucile & Hugo on 14/01/2021.
//

import UIKit


// classe qui herite de la classe biere basique
// son rôle -> représenter les bières que l'utilisateur aura ajouter à son tableau de chasse
class BiereUtilisateur: Biere {
    
    // attributs en plus
    var favorie: Bool
    var cheminImage: String
    var notePerso: Int
    let dateAjout: Date
    
    
    // constructeur
    init(nom: String = "Inconnu", categorie: String = "Inconnue", style: String = "Inconnu", description: String = "Vide", degreAlcool: Double = -1, brasserie: String = "Inconnue", ville: String = "Inconnue", pays: String = "Inconnu", siteWeb: String = "Inconnu", favorie: Bool = false, chemin: String = "parDefaut", notePerso: Int = 0) {
                
        self.favorie = favorie
        self.cheminImage = chemin
        self.notePerso = notePerso
        self.dateAjout = Date()
        

        // on appelle le constructeur de la classe mere
        super.init(nom: nom, categorie: categorie, style: style, description: description, degreAlcool: degreAlcool, brasserie: brasserie, ville: ville, pays: pays, siteWeb: siteWeb)
    }
    
    
    // surcharge du constructeur
    init(biere: Biere, favorie: Bool = false, chemin: String = "parDefaut", notePerso: Int = 0) {
        
        self.favorie = favorie
        self.cheminImage = chemin
        self.notePerso = notePerso
        self.dateAjout = Date()

        
        super.init(nom: biere.nom, categorie: biere.categorie, style: biere.style, description: biere.description, degreAlcool: biere.degreAlcool, brasserie: biere.brasserie, ville: biere.ville, pays: biere.pays, siteWeb: biere.siteWeb)
    }
    
    
    
    
} // classe biere utilisateur
